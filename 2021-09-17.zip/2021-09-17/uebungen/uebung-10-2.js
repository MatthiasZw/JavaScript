var init;
var aktWert;
var op;
var opdone;

function setVarsInit() {
    init = true;
    aktWert = 0;
    op = "";
    opdone = true;
}

function setze(wert){
    if (opdone == true) {
        document.Taschenrechner.eingabe.value = '';
        opdone = false;
    }
    document.Taschenrechner.eingabe.value = document.Taschenrechner.eingabe.value + wert;
}

function AnzeigeClear(){
    document.Taschenrechner.eingabe.value = '0';
    setVarsInit();
}

function anzeigeErgebnis(){
    DoOp();
    document.Taschenrechner.eingabe.value = '= ' + aktWert;
    setVarsInit();
}

function add(){
    DoOp();
    op = "+";
    opdone = true;
    document.Taschenrechner.eingabe.value = document.Taschenrechner.eingabe.value + " " + op;
}

function sub(){
    DoOp();
    op = "-";
    opdone = true;
    document.Taschenrechner.eingabe.value = document.Taschenrechner.eingabe.value + " " + op;
}

function mult() {
    DoOp();
    op = "*";
    opdone = true;
    document.Taschenrechner.eingabe.value = document.Taschenrechner.eingabe.value + " " + op;
}

function div() {
    DoOp();
    op = "/";
    opdone = true;
    document.Taschenrechner.eingabe.value = document.Taschenrechner.eingabe.value + " " + op;
}

/************ Zusatz *********/
function perc() {
    DoOp();
    op = "%";
    opdone = true;
    document.Taschenrechner.eingabe.value = document.Taschenrechner.eingabe.value + " " + op;
}

function mysqrt() {
    DoOp();
    op = "sqrt";
    opdone = true;
    document.Taschenrechner.eingabe.value = document.Taschenrechner.eingabe.value + " √";
}
/************ Ende Zusatz *********/

function DoOp() {
    if (init) {
        aktWert = parseFloat(document.Taschenrechner.eingabe.value);
        init = false;
    }
    if (op == "+")
        aktWert = aktWert + parseFloat(document.Taschenrechner.eingabe.value);
    if (op == "-")
        aktWert = aktWert - parseFloat(document.Taschenrechner.eingabe.value);
    if (op == "*")
        aktWert = aktWert * parseFloat(document.Taschenrechner.eingabe.value);
    if (op == "/")
        aktWert = aktWert / parseFloat(document.Taschenrechner.eingabe.value);

/************ Zusatz *********/
    if (op == "%") {
        aktWert = aktWert / 100;
    }
    if (op == "sqrt")
        aktWert = Math.sqrt(aktWert);
/************ Ende Zusatz *********/

}