/* === Kontrollstrukturen === */

if( Bedingung ) {
    //Anweisungen wenn wahr
} else if( Bedingung2 ) {
    //Anweisungen wenn Beingung2 wahr
} else {
    //Anweisungen wenn beide Bedingungen falsch
}

/* Switch Case */
switch( Selektor ) {
    case Wert1: Anweisungen; break;
    case Wert2: Anweisungen; break;
    //...
    default: Anweisungen;
}

/* Zählergesteuerte Wiederholung */
for( Initialisierung; Bedingung; Aktualisierung ) {
    Anweisung1;
    Anweisung2;
}

/* Kopfgesteuerte Wiederholung */
while( Bedingung ) {
    Anweisungsblock;
}

/* Fußgesteuerte Wiederholung */
do {
    Anweisungsblock;
} while( Bedingung );

/* Schleifensteuerung */
break; // verlässt die Schleife (bzw. die case-Anweisung)
continue; // bricht den aktuellen Schleifendurchlauf ab und springt zum nächsten Durchlauf
// ACHTUNG! continue kann zu Endlosschleifen führen, wenn falsch platziert

/* Iteration durch Objekte mit for in */
for( variable in object ) {
    Anweisungen;
    // in der Variable befindet sich immer der Wert der aktuellen Eigenschaft
}