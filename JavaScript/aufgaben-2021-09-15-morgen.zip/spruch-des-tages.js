var Weisheiten = new Array(10);
Weisheiten[0] = "Gäste und Reiher sehen am schönsten aus, wenn sie sich erheben.";
Weisheiten[1] = "Vier Dinge kommen nicht zurück: der abgeschossene Pfeil, das gesprochene Wort, die verpasste Gelegenheit und das versäumte Leben.";
Weisheiten[2] = "Wer wenig gesehen hat, staunt viel.";
Weisheiten[3] = "Um klarer zu sehen, genügt es oft, nur den Blick schweifen zu lassen.";
Weisheiten[4] = "Wer mich korrekterweise kritisiert, ist mein Lehrer. Wer mir fälschlich schmeichelt, ist mein Feind.";
Weisheiten[5] = "Wer Angst hat, die Würfel zu schütteln, wird niemals eine Sechs werfen.";
Weisheiten[6] = "Wenn man auch den Kopf in den Sand steckt, der Hintern bleibt zu sehen.";
Weisheiten[7] = "Wir lieben das Leben nur, weil es uns ungewiss ist.";
Weisheiten[8] = "Der Frosch im Brunnen weiß nichts vom großen Ozean.";
Weisheiten[9] = "Sich an den einfachen Dingen des Lebens zu erfreuen, bedeutet sein Leben zu genießen.";


